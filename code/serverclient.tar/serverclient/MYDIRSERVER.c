#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<errno.h>



void recvdir(char *name,int newfd)
{
    while(1)
    {
        //读客户端的文件信息
        char buf[4096];
        int sum=0;
        int sumw=0;
        int retw=0;
        int ret;
        memset(buf,0,sizeof(buf));
        //读文件类型
        ret=read(newfd,buf,1);
        printf("type:%s\n",buf);
        int lengthargv;
        if(ret<=0)
        {
            break;
        }
        if(buf[0]=='d')//说明是目录
        {
            //先读目录长度
            memset(buf,0,sizeof(buf));
            ret=read(newfd,buf,sizeof(int));
            if(ret<=0)
            {
                continue;
            }
            lengthargv=*(int *)buf;
            lengthargv=ntohl(lengthargv);//将网络整型转为本地主机的整型
            printf("文件名长度是:%d\n",lengthargv);

            //读目录名

            memset(buf,0,sizeof(buf));
            ret=read(newfd,buf,lengthargv);
            if(ret<=0)
            {
                
                continue;
                
            }
            printf("buf=%s\n",buf);
            ret=mkdir(buf,0777);
            printf("ret=%d\n",ret);

            //    recvdir(buf,newfd);
        }else if(buf[0]=='f')//表示普通文件
        {
            memset(buf,0,sizeof(buf));
            //读文件名长度
            ret=read(newfd,buf,sizeof(int));
            if(ret<=0)
            {
                continue;
            }
            lengthargv=*(int *)buf;
            lengthargv=ntohl(lengthargv);//将网络整型转为本地主机的整型
            printf("文件名长度是:%d\n",lengthargv);

            //读文件名
            memset(buf,0,sizeof(buf));
            ret=read(newfd,buf,lengthargv);
            if(ret<=0)
            {
                continue;
            }
            printf("文件名是:%s\n",buf);

            //读文件
            
            int fd1=open(buf,O_WRONLY|O_CREAT|O_TRUNC,0777);
            printf("fd1=%d\n",fd1);
            if(fd1==-1)
            {
                perror("fd1:");
    //            break;
            }
            //先读文件的长度
            memset(buf,0,sizeof(buf));
            ret=read(newfd,buf,sizeof(int));
            if(ret<=0)
            {
                continue;
            }
            lengthargv=*(int *)buf;
            lengthargv=ntohl(lengthargv);//将网络整型转为本地主机的整型
            printf("文件长度是:%d\n",lengthargv);

            int sum=0;//比较写入数据大小，避免粘包现象
            int readSize=0;
            while(1)
            {
                readSize=(lengthargv-sum)>sizeof(buf)?sizeof(buf):(lengthargv-sum);//-这一步必须要有，为的是防止粘包问题
                memset(buf,0,sizeof(buf));
                ret=read(newfd,buf,readSize);
                if(ret==0)
                {
                    printf("ret==0\n");
                    break;
                }else if(ret<0&&errno==EINTR)
                {
                    perror("ret:");
                    continue;
                }
                sum+=ret;
                printf("sum=%d\n",sum);
                write(fd1,buf,ret);
                if(sum==lengthargv)
                {
                    close(fd1);
                    break;
                }
            }

        }else if(buf[0]=='x')
        {
            printf("check paster packet buf=%s\n",buf);
            break;
        }else
        {
            printf("buf=%s\n",buf);
            break;
        }        
    }
}

int main()
{

    //创建套接字
    int fd=socket(AF_INET,SOCK_STREAM,0);

    //设置结诟体，用来绑定IP和端口
    struct sockaddr_in addr;
    addr.sin_addr.s_addr=inet_addr("0.0.0.0");
    addr.sin_family=AF_INET;
    addr.sin_port=htons(23999);    

    //绑定地址端口信息到socket文件
    bind(fd,(struct sockaddr*)&addr,sizeof(addr));

    //监听
    listen(fd,10);//同时监听10个客户端
    int newfd=accept(fd,NULL,NULL);//创建服务器和客户端之间通信的文件
    if(newfd<0)
    {
        printf("communication fails.\n");
        return;
    } 

    recvdir(NULL,newfd);   
    close(newfd);
    return 0;
}
