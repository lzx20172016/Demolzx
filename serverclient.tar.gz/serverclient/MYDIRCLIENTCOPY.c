#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include<dirent.h>

//本程序用来向服务器传送目录及目录中的所有文件
//发送目录格式是d,目录长度，目录名,
//发送文件格式是f,文件名长度，文件名，文件长度，文件内容
//发送文件格式是x表示没有文件了
//本程序只传送普通文件和目录
//获得文件长度
int getlen(char *name)
{
    struct stat buf;
    stat(name,&buf);
    return buf.st_size;
}
//判断文件名是不是目录的类型
int ISDIR(char *name)
{
    struct stat buf;
    stat(name,&buf);
    if(S_ISDIR(buf.st_mode))
    {
        printf("S_ISDIR:this is a dir\n");
        return 1;
    }else if(S_ISREG(buf.st_mode))
    {
        printf("S_ISREG：this is a regular file.\n");
        return 0;
    }else
    {
        printf("this is not a file in them.\n");
        return -1;
    }    
}

//发送文件长度
void sendlen(int len,int cl)
{

    printf("文件名长度是:%d\n",len);
    len=htonl(len);//将len转换成网络大端
    write(cl,(char *)&len,sizeof(int));//写文件名长度
}

//发送文件
void sendfile(char *name,int cl)
{
    write(cl,"f",1);

    int len;
    //发送文件名长度防止出现粘包现象
    sendlen(strlen(name),cl);
    write(cl,name,strlen(name));

    //发送文件内容包括长度
    len=getlen(name);//获得文件长度 
    sendlen(len,cl);

    int sum=0;//记录读取的总字节数
    char buf[4986];

    int fd=open(name,O_RDONLY);
    if(fd==-1)
    {
        printf("open fail fails.\n");
        return ;
    }
    while(1)
    {
        memset(buf,0,sizeof(buf));
        int ret=read(fd,buf,sizeof(buf));//read读成功返回读到的字节数
        if(ret<=0)
        {
            break;
        }
        sum+=ret;
        write(cl,buf,ret);
        if(sum==len)
        {
            break;
        }
    }
    return;
}


//发送目录
void senddir(char *name,int cl)
{
    //判断是不是目录
    if(ISDIR(name)==0)//说明是文件
    {
        printf("name=%s\n",name);
        sendfile(name,cl);
        return;
    }else if(ISDIR(name)!=1)//说明既不是目录也不是文件
    {
        printf("this file is not a directory and regular fiel.\n");
        return;
    }
#if 0
    struct stat bufstat;
    stat(argv[1],&bufstat);
    if(!S_ISDIR(bufstat.st_mode))
    {
        printf("give a directory.\n");
        return -1;
    }
#endif
    //传目录标记
    write(cl,"d",1);
    //写目录名长度
    sendlen(strlen(name),cl);
    //传目录名
    write(cl,name,strlen(name));

    //打开目录，进行目录内的文件传输
    DIR *dir=opendir(name);
    if(dir==NULL)
    {
        perror("opendir:");
        return;
    } 
    
        char pfilenametemp[512]={0};
        strcpy(pfilenametemp,name);
        strcat(pfilenametemp,"/");

    while(1)
    {

        struct dirent *pdir=readdir(dir);//读目录

        if(NULL==pdir)
        {
            perror("readdir:\n");
            return;
        } 
        printf("pdir->name:%s\n",pdir->d_name);
        if(pdir->d_name[0]=='.')
        {
            continue;
        }
        //判断是不是文件（注意虽然dirent结构体内有关于文件类型的定义，但是不是所有的操作系统都能这样判断        
        char pfilename[512]={0};
        strcpy(pfilename,pfilenametemp);
        strcat(pfilename,pdir->d_name);
        printf("pfilenametemp:%s\n",pfilenametemp);
        printf("pfilename:%s\n",pfilename);
        senddir(pfilename,cl);
    }

}
int main(int argc,char **argv)
{
    if(argc!=2)
    {
        printf("USAGE:[FILE1][FILE2]\n");
        return -1;
    }
    //建立socket文件
    int cl=socket(AF_INET,SOCK_STREAM,0);

    //建立绑定套接字的地址
    struct sockaddr_in addr;
    addr.sin_family=AF_INET;
    addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    addr.sin_port=htons(23999);

    //连接socket文件和套接字
    if(connect(cl,(struct sockaddr*)&addr,sizeof(addr))==-1)
    {
        perror("connect");
        return -1;
    }

    senddir(argv[1],cl);
    return 0;
}

